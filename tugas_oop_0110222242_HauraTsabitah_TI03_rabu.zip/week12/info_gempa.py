from gempa import *

c1 = bmpg("Banten", 1.2)
c1.cetak()
print()

c2 = bmpg("Palu", 6.1)
c2.cetak()
print()

c3 = bmpg("Cianjur", 5.6)
c3.cetak()
print()

c4 = bmpg("Jayapura", 3.3)
c4.cetak()
print()

c5 = bmpg("Garut", 4.0)
c5.cetak()